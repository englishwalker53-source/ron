// RON Order Management System - Client Side JavaScript

class OrderManager {
    constructor() {
        this.initializeData();
        this.bindEvents();
        this.updateDisplay();
    }

    initializeData() {
        // Initialize settings if not exists
        if (!localStorage.getItem('ronSettings')) {
            const defaultSettings = {
                unitPrice: 0.35 // Default LKR per RON
            };
            localStorage.setItem('ronSettings', JSON.stringify(defaultSettings));
        }

        // Initialize orders if not exists
        if (!localStorage.getItem('ronOrders')) {
            localStorage.setItem('ronOrders', JSON.stringify([]));
        }
    }

    getSettings() {
        return JSON.parse(localStorage.getItem('ronSettings'));
    }

    getOrders() {
        return JSON.parse(localStorage.getItem('ronOrders'));
    }

    saveOrder(order) {
        const orders = this.getOrders();
        orders.push(order);
        localStorage.setItem('ronOrders', JSON.stringify(orders));
    }

    generateInvoiceNumber() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        
        // Get existing orders to determine next sequence number
        const orders = this.getOrders();
        const todayOrders = orders.filter(order => 
            order.invoiceNo.includes(`${year}${month}${day}`)
        );
        
        const sequence = String(todayOrders.length + 1).padStart(3, '0');
        return `INV-${year}${month}${day}-${sequence}`;
    }

    calculateTotal(amountRON, unitPrice) {
        return (parseFloat(amountRON) * parseFloat(unitPrice)).toFixed(2);
    }

    formatDate(date) {
        return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    updateDisplay() {
        const settings = this.getSettings();
        const currentRateElement = document.getElementById('currentRate');
        const displayUnitPriceElement = document.getElementById('displayUnitPrice');
        
        if (currentRateElement) {
            currentRateElement.textContent = `${settings.unitPrice} LKR`;
        }
        
        if (displayUnitPriceElement) {
            displayUnitPriceElement.textContent = `${settings.unitPrice} LKR`;
        }
    }

    updateCalculation() {
        const amountRON = document.getElementById('amountRON').value || 0;
        const settings = this.getSettings();
        const total = this.calculateTotal(amountRON, settings.unitPrice);

        document.getElementById('displayRON').textContent = `${parseFloat(amountRON).toFixed(2)} RON`;
        document.getElementById('displayUnitPrice').textContent = `${settings.unitPrice} LKR`;
        document.getElementById('displayTotal').textContent = `${total} LKR`;
    }

    bindEvents() {
        // Amount input change event
        const amountInput = document.getElementById('amountRON');
        if (amountInput) {
            amountInput.addEventListener('input', () => this.updateCalculation());
        }

        // Form submit event
        const orderForm = document.getElementById('orderForm');
        if (orderForm) {
            orderForm.addEventListener('submit', (e) => this.handleOrderSubmit(e));
        }

        // Modal close events
        const modal = document.getElementById('successModal');
        const closeBtn = document.querySelector('.close');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }
        
        if (modal) {
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal();
                }
            });
        }
    }

    handleOrderSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const settings = this.getSettings();
        
        const order = {
            id: Date.now(),
            invoiceNo: this.generateInvoiceNumber(),
            date: new Date().toISOString(),
            clientName: formData.get('fullName'),
            amountRON: parseFloat(formData.get('amountRON')),
            unitPrice: settings.unitPrice,
            totalLKR: this.calculateTotal(formData.get('amountRON'), settings.unitPrice),
            bankAccount: formData.get('bankAccount'),
            status: 'Pending'
        };

        this.saveOrder(order);
        this.showSuccessModal(order);
        e.target.reset();
        this.updateCalculation();
    }

    showSuccessModal(order) {
        const modal = document.getElementById('successModal');
        const orderDetails = document.getElementById('orderDetails');
        
        orderDetails.innerHTML = `
            <div style="background: #f7fafc; padding: 20px; border-radius: 10px; margin: 15px 0;">
                <p><strong>Invoice Number:</strong> ${order.invoiceNo}</p>
                <p><strong>Client Name:</strong> ${order.clientName}</p>
                <p><strong>Amount in RON:</strong> ${order.amountRON}</p>
                <p><strong>Unit Price:</strong> ${order.unitPrice} LKR</p>
                <p><strong>Total in LKR:</strong> ${order.totalLKR} LKR</p>
                <p><strong>Bank Account:</strong> ${order.bankAccount}</p>
                <p><strong>Status:</strong> ${order.status}</p>
                <p><strong>Date:</strong> ${this.formatDate(new Date(order.date))}</p>
            </div>
        `;
        
        modal.style.display = 'block';
    }

    closeModal() {
        const modal = document.getElementById('successModal');
        modal.style.display = 'none';
    }
}

// Global function for modal close button
function closeModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'none';
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('RON Order Management System - Client Side Loaded');
    new OrderManager();
});