# RON Order Management System - Implementation Plan

## Files to Create:
1. **index.html** - Main client page with order form
2. **admin.html** - Admin panel for order management
3. **style.css** - Responsive CSS styling
4. **script.js** - Client-side JavaScript functionality
5. **admin.js** - Admin panel JavaScript functionality

## Features Implementation:

### Client Page (index.html):
- Order form with Full Name, Amount in RON, Bank Account fields
- Auto-calculate LKR total using current unit price
- Display current unit price per RON
- Generate unique invoice numbers (INV-YYYYMMDD-XXX format)
- Save orders to localStorage with "Pending" status
- Success message with invoice number

### Admin Page (admin.html):
- Password-protected login (default: admin123)
- Orders table with all required columns
- Status update functionality (Paid/Pending)
- Unit price update section
- Responsive design

### Data Storage (localStorage):
- orders: Array of order objects
- settings: Object with unitPrice
- Simulates MySQL database structure

## Database Schema Simulation:
- orders: id, invoiceNo, date, clientName, amountRON, unitPrice, totalLKR, bankAccount, status
- settings: unitPrice (default: 0.35 LKR per RON)