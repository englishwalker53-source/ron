// RON Order Management System - Admin Panel JavaScript

class AdminPanel {
    constructor() {
        this.isLoggedIn = false;
        this.adminPassword = 'admin123'; // In production, this should be hashed and stored securely
        this.bindEvents();
        this.checkLoginStatus();
    }

    bindEvents() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        // Settings form
        const settingsForm = document.getElementById('settingsForm');
        if (settingsForm) {
            settingsForm.addEventListener('submit', (e) => this.handleSettingsUpdate(e));
        }
    }

    checkLoginStatus() {
        // Check if admin is already logged in (session storage)
        const loginStatus = sessionStorage.getItem('adminLoggedIn');
        if (loginStatus === 'true') {
            this.showAdminPanel();
        }
    }

    handleLogin(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const password = formData.get('password');

        if (password === this.adminPassword) {
            this.isLoggedIn = true;
            sessionStorage.setItem('adminLoggedIn', 'true');
            this.showAdminPanel();
            this.showSuccessMessage('Login successful!');
        } else {
            alert('Invalid password. Please try again.');
        }
    }

    handleLogout() {
        this.isLoggedIn = false;
        sessionStorage.removeItem('adminLoggedIn');
        this.showLoginForm();
        this.showSuccessMessage('Logged out successfully!');
    }

    showLoginForm() {
        document.getElementById('loginSection').style.display = 'block';
        document.getElementById('adminPanel').style.display = 'none';
    }

    showAdminPanel() {
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'block';
        this.loadSettings();
        this.loadOrders();
    }

    getSettings() {
        const settings = localStorage.getItem('ronSettings');
        return settings ? JSON.parse(settings) : { unitPrice: 0.35 };
    }

    getOrders() {
        const orders = localStorage.getItem('ronOrders');
        return orders ? JSON.parse(orders) : [];
    }

    saveSettings(settings) {
        localStorage.setItem('ronSettings', JSON.stringify(settings));
    }

    saveOrders(orders) {
        localStorage.setItem('ronOrders', JSON.stringify(orders));
    }

    loadSettings() {
        const settings = this.getSettings();
        const unitPriceInput = document.getElementById('unitPrice');
        if (unitPriceInput) {
            unitPriceInput.value = settings.unitPrice;
        }
    }

    handleSettingsUpdate(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const unitPrice = parseFloat(formData.get('unitPrice'));

        if (unitPrice > 0) {
            const settings = { unitPrice: unitPrice };
            this.saveSettings(settings);
            this.showSuccessMessage('Unit price updated successfully!');
        } else {
            alert('Please enter a valid unit price greater than 0.');
        }
    }

    loadOrders() {
        const orders = this.getOrders();
        const tableBody = document.getElementById('ordersTableBody');
        const noOrdersDiv = document.getElementById('noOrders');
        const ordersTable = document.getElementById('ordersTable');

        if (orders.length === 0) {
            ordersTable.style.display = 'none';
            noOrdersDiv.style.display = 'block';
            return;
        }

        ordersTable.style.display = 'table';
        noOrdersDiv.style.display = 'none';

        // Sort orders by date (newest first)
        orders.sort((a, b) => new Date(b.date) - new Date(a.date));

        tableBody.innerHTML = orders.map((order, index) => `
            <tr>
                <td>${index + 1}</td>
                <td>${this.formatDate(new Date(order.date))}</td>
                <td><strong>${order.invoiceNo}</strong></td>
                <td>${order.clientName}</td>
                <td>${order.amountRON}</td>
                <td>${order.unitPrice}</td>
                <td>${order.totalLKR}</td>
                <td>${order.bankAccount}</td>
                <td>
                    <span class="status-badge ${order.status.toLowerCase() === 'paid' ? 'status-paid' : 'status-pending'}">
                        ${order.status}
                    </span>
                </td>
                <td>
                    <button class="btn ${order.status.toLowerCase() === 'paid' ? 'btn-warning' : 'btn-success'}" 
                            onclick="adminPanel.toggleOrderStatus(${order.id})" 
                            style="font-size: 12px; padding: 5px 10px;">
                        Mark as ${order.status.toLowerCase() === 'paid' ? 'Pending' : 'Paid'}
                    </button>
                </td>
            </tr>
        `).join('');
    }

    toggleOrderStatus(orderId) {
        const orders = this.getOrders();
        const orderIndex = orders.findIndex(order => order.id === orderId);
        
        if (orderIndex !== -1) {
            orders[orderIndex].status = orders[orderIndex].status === 'Paid' ? 'Pending' : 'Paid';
            this.saveOrders(orders);
            this.loadOrders();
            this.showSuccessMessage(`Order status updated to ${orders[orderIndex].status}!`);
        }
    }

    formatDate(date) {
        return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showSuccessMessage(message) {
        const successDiv = document.getElementById('successMessage');
        const successText = document.getElementById('successText');
        
        successText.textContent = message;
        successDiv.style.display = 'block';
        
        setTimeout(() => {
            successDiv.style.display = 'none';
        }, 3000);
    }
}

// Global variable for admin panel instance
let adminPanel;

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('RON Order Management System - Admin Panel Loaded');
    adminPanel = new AdminPanel();
});