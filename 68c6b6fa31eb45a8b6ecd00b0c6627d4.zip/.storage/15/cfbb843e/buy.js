// Romanian Leu Buy Page JavaScript

class BuyOrderManager {
    constructor() {
        this.initializeData();
        this.bindEvents();
        this.updateDisplay();
    }

    initializeData() {
        // Initialize settings if not exists
        if (!localStorage.getItem('ronSettings')) {
            const defaultSettings = {
                sellingRate: 0.35, // Rate for selling RON to customers
                buyingRate: 0.33   // Rate for buying RON from customers
            };
            localStorage.setItem('ronSettings', JSON.stringify(defaultSettings));
        }

        // Initialize buy orders if not exists
        if (!localStorage.getItem('ronBuyOrders')) {
            localStorage.setItem('ronBuyOrders', JSON.stringify([]));
        }
    }

    getSettings() {
        return JSON.parse(localStorage.getItem('ronSettings'));
    }

    getBuyOrders() {
        return JSON.parse(localStorage.getItem('ronBuyOrders'));
    }

    saveBuyOrder(order) {
        const orders = this.getBuyOrders();
        orders.push(order);
        localStorage.setItem('ronBuyOrders', JSON.stringify(orders));
    }

    generateInvoiceNumber() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        
        const orders = this.getBuyOrders();
        const todayOrders = orders.filter(order => 
            order.invoiceNo.includes(`${year}${month}${day}`)
        );
        
        const sequence = String(todayOrders.length + 1).padStart(3, '0');
        return `BUY-${year}${month}${day}-${sequence}`;
    }

    calculateTotal(amountRON, rate) {
        return (parseFloat(amountRON) * parseFloat(rate)).toFixed(2);
    }

    formatDate(date) {
        return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    updateDisplay() {
        const settings = this.getSettings();
        const currentRateElement = document.getElementById('currentRate');
        const displayUnitPriceElement = document.getElementById('displayUnitPrice');
        
        if (currentRateElement) {
            currentRateElement.textContent = `${settings.sellingRate} LKR`;
        }
        
        if (displayUnitPriceElement) {
            displayUnitPriceElement.textContent = `${settings.sellingRate} LKR`;
        }
    }

    updateCalculation() {
        const amountRON = document.getElementById('amountRON').value || 0;
        const settings = this.getSettings();
        const total = this.calculateTotal(amountRON, settings.sellingRate);

        document.getElementById('displayRON').textContent = `${parseFloat(amountRON).toFixed(2)} RON`;
        document.getElementById('displayUnitPrice').textContent = `${settings.sellingRate} LKR`;
        document.getElementById('displayTotal').textContent = `${total} LKR`;
    }

    bindEvents() {
        const amountInput = document.getElementById('amountRON');
        if (amountInput) {
            amountInput.addEventListener('input', () => this.updateCalculation());
        }

        const buyForm = document.getElementById('buyForm');
        if (buyForm) {
            buyForm.addEventListener('submit', (e) => this.handleBuyOrderSubmit(e));
        }

        const modal = document.getElementById('successModal');
        const closeBtn = document.querySelector('.close');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }
        
        if (modal) {
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal();
                }
            });
        }
    }

    handleBuyOrderSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const settings = this.getSettings();
        
        const order = {
            id: Date.now(),
            invoiceNo: this.generateInvoiceNumber(),
            date: new Date().toISOString(),
            clientName: formData.get('fullName'),
            amountRON: parseFloat(formData.get('amountRON')),
            rate: settings.sellingRate,
            totalLKR: this.calculateTotal(formData.get('amountRON'), settings.sellingRate),
            bankAccount: formData.get('bankAccount'),
            deliveryMethod: formData.get('deliveryMethod'),
            orderType: 'Buy',
            status: 'Pending'
        };

        this.saveBuyOrder(order);
        this.showSuccessModal(order);
        e.target.reset();
        this.updateCalculation();
    }

    showSuccessModal(order) {
        const modal = document.getElementById('successModal');
        const orderDetails = document.getElementById('orderDetails');
        
        orderDetails.innerHTML = `
            <div style="background: #f7fafc; padding: 20px; border-radius: 10px; margin: 15px 0;">
                <p><strong>Invoice Number:</strong> ${order.invoiceNo}</p>
                <p><strong>Order Type:</strong> ${order.orderType}</p>
                <p><strong>Client Name:</strong> ${order.clientName}</p>
                <p><strong>RON Amount:</strong> ${order.amountRON}</p>
                <p><strong>Rate:</strong> ${order.rate} LKR per RON</p>
                <p><strong>Total Payment:</strong> ${order.totalLKR} LKR</p>
                <p><strong>Bank Account:</strong> ${order.bankAccount}</p>
                <p><strong>Delivery Method:</strong> ${order.deliveryMethod}</p>
                <p><strong>Status:</strong> ${order.status}</p>
                <p><strong>Date:</strong> ${this.formatDate(new Date(order.date))}</p>
            </div>
        `;
        
        modal.style.display = 'block';
    }

    closeModal() {
        const modal = document.getElementById('successModal');
        modal.style.display = 'none';
    }
}

function closeModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('Romanian Leu Buy Page Loaded');
    new BuyOrderManager();
});