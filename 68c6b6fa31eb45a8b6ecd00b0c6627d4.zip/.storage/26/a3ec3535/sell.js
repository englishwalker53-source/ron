// Romanian Leu Sell Page JavaScript

class SellOrderManager {
    constructor() {
        this.initializeData();
        this.bindEvents();
        this.updateDisplay();
    }

    initializeData() {
        // Initialize settings if not exists
        if (!localStorage.getItem('ronSettings')) {
            const defaultSettings = {
                sellingRate: 0.35, // Rate for selling RON to customers
                buyingRate: 0.33   // Rate for buying RON from customers
            };
            localStorage.setItem('ronSettings', JSON.stringify(defaultSettings));
        }

        // Initialize sell orders if not exists
        if (!localStorage.getItem('ronSellOrders')) {
            localStorage.setItem('ronSellOrders', JSON.stringify([]));
        }
    }

    getSettings() {
        return JSON.parse(localStorage.getItem('ronSettings'));
    }

    getSellOrders() {
        return JSON.parse(localStorage.getItem('ronSellOrders'));
    }

    saveSellOrder(order) {
        const orders = this.getSellOrders();
        orders.push(order);
        localStorage.setItem('ronSellOrders', JSON.stringify(orders));
    }

    generateInvoiceNumber() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        
        const orders = this.getSellOrders();
        const todayOrders = orders.filter(order => 
            order.invoiceNo.includes(`${year}${month}${day}`)
        );
        
        const sequence = String(todayOrders.length + 1).padStart(3, '0');
        return `SELL-${year}${month}${day}-${sequence}`;
    }

    calculateTotal(amountRON, rate) {
        return (parseFloat(amountRON) * parseFloat(rate)).toFixed(2);
    }

    formatDate(date) {
        return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    validateWhatsAppNumber(number) {
        // Remove all spaces and special characters except +
        const cleanNumber = number.replace(/[^\d+]/g, '');
        
        // Check if it starts with + and has 10-15 digits
        const whatsappPattern = /^\+\d{10,15}$/;
        return whatsappPattern.test(cleanNumber);
    }

    updateDisplay() {
        const settings = this.getSettings();
        const currentRateElement = document.getElementById('currentRate');
        const displayUnitPriceElement = document.getElementById('displayUnitPrice');
        
        if (currentRateElement) {
            currentRateElement.textContent = `${settings.buyingRate} LKR`;
        }
        
        if (displayUnitPriceElement) {
            displayUnitPriceElement.textContent = `${settings.buyingRate} LKR`;
        }
    }

    updateCalculation() {
        const amountRON = document.getElementById('amountRON').value || 0;
        const settings = this.getSettings();
        const total = this.calculateTotal(amountRON, settings.buyingRate);

        document.getElementById('displayRON').textContent = `${parseFloat(amountRON).toFixed(2)} RON`;
        document.getElementById('displayUnitPrice').textContent = `${settings.buyingRate} LKR`;
        document.getElementById('displayTotal').textContent = `${total} LKR`;
    }

    bindEvents() {
        const amountInput = document.getElementById('amountRON');
        if (amountInput) {
            amountInput.addEventListener('input', () => this.updateCalculation());
        }

        // WhatsApp number validation
        const whatsappInput = document.getElementById('whatsappNumber');
        if (whatsappInput) {
            whatsappInput.addEventListener('blur', (e) => {
                const number = e.target.value.trim();
                if (number && !this.validateWhatsAppNumber(number)) {
                    e.target.setCustomValidity('Please enter a valid WhatsApp number with country code (e.g., +94771234567)');
                    e.target.reportValidity();
                } else {
                    e.target.setCustomValidity('');
                }
            });

            whatsappInput.addEventListener('input', (e) => {
                e.target.setCustomValidity('');
            });
        }

        const sellForm = document.getElementById('sellForm');
        if (sellForm) {
            sellForm.addEventListener('submit', (e) => this.handleSellOrderSubmit(e));
        }

        const modal = document.getElementById('successModal');
        const closeBtn = document.querySelector('.close');
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeModal());
        }
        
        if (modal) {
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal();
                }
            });
        }
    }

    handleSellOrderSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const whatsappNumber = formData.get('whatsappNumber').trim();
        
        // Validate WhatsApp number before submission
        if (!this.validateWhatsAppNumber(whatsappNumber)) {
            alert('Please enter a valid WhatsApp number with country code (e.g., +94771234567)');
            return;
        }
        
        const settings = this.getSettings();
        
        const order = {
            id: Date.now(),
            invoiceNo: this.generateInvoiceNumber(),
            date: new Date().toISOString(),
            clientName: formData.get('fullName'),
            whatsappNumber: whatsappNumber,
            amountRON: parseFloat(formData.get('amountRON')),
            rate: settings.buyingRate,
            totalLKR: this.calculateTotal(formData.get('amountRON'), settings.buyingRate),
            bankAccount: formData.get('bankAccount'),
            ronSource: formData.get('ronSource'),
            orderType: 'Sell',
            status: 'Pending'
        };

        this.saveSellOrder(order);
        this.showSuccessModal(order);
        e.target.reset();
        this.updateCalculation();
    }

    showSuccessModal(order) {
        const modal = document.getElementById('successModal');
        const orderDetails = document.getElementById('orderDetails');
        
        orderDetails.innerHTML = `
            <div style="background: #f7fafc; padding: 20px; border-radius: 10px; margin: 15px 0;">
                <p><strong>Invoice Number:</strong> ${order.invoiceNo}</p>
                <p><strong>Order Type:</strong> ${order.orderType}</p>
                <p><strong>Client Name:</strong> ${order.clientName}</p>
                <p><strong>WhatsApp Number:</strong> ${order.whatsappNumber}</p>
                <p><strong>RON Amount:</strong> ${order.amountRON}</p>
                <p><strong>Rate:</strong> ${order.rate} LKR per RON</p>
                <p><strong>You will receive:</strong> ${order.totalLKR} LKR</p>
                <p><strong>Bank Account:</strong> ${order.bankAccount}</p>
                <p><strong>RON Source:</strong> ${order.ronSource}</p>
                <p><strong>Status:</strong> ${order.status}</p>
                <p><strong>Date:</strong> ${this.formatDate(new Date(order.date))}</p>
            </div>
        `;
        
        modal.style.display = 'block';
    }

    closeModal() {
        const modal = document.getElementById('successModal');
        modal.style.display = 'none';
    }
}

function closeModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('Romanian Leu Sell Page Loaded');
    new SellOrderManager();
});