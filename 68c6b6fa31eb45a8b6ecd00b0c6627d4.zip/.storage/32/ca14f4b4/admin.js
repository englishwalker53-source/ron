// Romanian Leu Exchange - Admin Panel JavaScript

class AdminPanel {
    constructor() {
        this.isLoggedIn = false;
        this.adminPassword = 'admin123';
        this.bindEvents();
        this.checkLoginStatus();
    }

    bindEvents() {
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        const settingsForm = document.getElementById('settingsForm');
        if (settingsForm) {
            settingsForm.addEventListener('submit', (e) => this.handleSettingsUpdate(e));
        }
    }

    checkLoginStatus() {
        const loginStatus = sessionStorage.getItem('adminLoggedIn');
        if (loginStatus === 'true') {
            this.showAdminPanel();
        }
    }

    handleLogin(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const password = formData.get('password');

        if (password === this.adminPassword) {
            this.isLoggedIn = true;
            sessionStorage.setItem('adminLoggedIn', 'true');
            this.showAdminPanel();
            this.showSuccessMessage('Login successful!');
        } else {
            alert('Invalid password. Please try again.');
        }
    }

    handleLogout() {
        this.isLoggedIn = false;
        sessionStorage.removeItem('adminLoggedIn');
        this.showLoginForm();
        this.showSuccessMessage('Logged out successfully!');
    }

    showLoginForm() {
        document.getElementById('loginSection').style.display = 'block';
        document.getElementById('adminPanel').style.display = 'none';
    }

    showAdminPanel() {
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'block';
        this.loadSettings();
        this.loadAllOrders();
    }

    getSettings() {
        const settings = localStorage.getItem('ronSettings');
        return settings ? JSON.parse(settings) : { sellingRate: 0.35, buyingRate: 0.33 };
    }

    getBuyOrders() {
        const orders = localStorage.getItem('ronBuyOrders');
        return orders ? JSON.parse(orders) : [];
    }

    getSellOrders() {
        const orders = localStorage.getItem('ronSellOrders');
        return orders ? JSON.parse(orders) : [];
    }

    saveSettings(settings) {
        localStorage.setItem('ronSettings', JSON.stringify(settings));
    }

    saveBuyOrders(orders) {
        localStorage.setItem('ronBuyOrders', JSON.stringify(orders));
    }

    saveSellOrders(orders) {
        localStorage.setItem('ronSellOrders', JSON.stringify(orders));
    }

    loadSettings() {
        const settings = this.getSettings();
        const sellingRateInput = document.getElementById('sellingRate');
        const buyingRateInput = document.getElementById('buyingRate');
        
        if (sellingRateInput) {
            sellingRateInput.value = settings.sellingRate;
        }
        if (buyingRateInput) {
            buyingRateInput.value = settings.buyingRate;
        }
    }

    handleSettingsUpdate(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const sellingRate = parseFloat(formData.get('sellingRate'));
        const buyingRate = parseFloat(formData.get('buyingRate'));

        if (sellingRate > 0 && buyingRate > 0) {
            const settings = { sellingRate: sellingRate, buyingRate: buyingRate };
            this.saveSettings(settings);
            this.showSuccessMessage('Exchange rates updated successfully!');
        } else {
            alert('Please enter valid rates greater than 0.');
        }
    }

    formatWhatsAppNumber(number) {
        // Check if number exists and is a string
        if (!number || typeof number !== 'string') {
            return 'N/A';
        }
        
        // Format WhatsApp number for display
        if (number.startsWith('+94')) {
            return number.replace('+94', '+94 ') + ' (WhatsApp)';
        }
        return number + ' (WhatsApp)';
    }

    getWhatsAppLink(number) {
        // Check if number exists and is valid
        if (!number || typeof number !== 'string') {
            return '#';
        }
        
        // Remove + for WhatsApp URL
        const cleanNumber = number.replace('+', '');
        return `https://wa.me/${cleanNumber}`;
    }

    loadAllOrders() {
        const buyOrders = this.getBuyOrders();
        const sellOrders = this.getSellOrders();
        const allOrders = [...buyOrders, ...sellOrders];
        
        const tableBody = document.getElementById('ordersTableBody');
        const noOrdersDiv = document.getElementById('noOrders');
        const ordersTable = document.getElementById('ordersTable');

        if (allOrders.length === 0) {
            ordersTable.style.display = 'none';
            noOrdersDiv.style.display = 'block';
            return;
        }

        ordersTable.style.display = 'table';
        noOrdersDiv.style.display = 'none';

        // Sort orders by date (newest first)
        allOrders.sort((a, b) => new Date(b.date) - new Date(a.date));

        tableBody.innerHTML = allOrders.map((order, index) => {
            // Handle missing whatsappNumber for backward compatibility
            const whatsappNumber = order.whatsappNumber || 'N/A';
            const whatsappLink = this.getWhatsAppLink(order.whatsappNumber);
            const formattedWhatsApp = this.formatWhatsAppNumber(order.whatsappNumber);
            
            return `
            <tr>
                <td>${index + 1}</td>
                <td>${this.formatDate(new Date(order.date))}</td>
                <td><strong>${order.invoiceNo}</strong></td>
                <td>${order.clientName}</td>
                <td class="whatsapp-cell">
                    ${whatsappNumber !== 'N/A' ? 
                        `<a href="${whatsappLink}" target="_blank" class="whatsapp-link">${formattedWhatsApp}</a>` : 
                        '<span class="no-whatsapp">N/A</span>'
                    }
                </td>
                <td>
                    <span class="order-type ${order.orderType.toLowerCase()}">${order.orderType}</span>
                </td>
                <td>${order.amountRON}</td>
                <td>${order.rate}</td>
                <td>${order.totalLKR}</td>
                <td>${order.bankAccount}</td>
                <td>
                    <span class="status-badge ${order.status.toLowerCase() === 'paid' ? 'status-paid' : 'status-pending'}">
                        ${order.status}
                    </span>
                </td>
                <td>
                    <button class="btn ${order.status.toLowerCase() === 'paid' ? 'btn-warning' : 'btn-success'}" 
                            onclick="adminPanel.toggleOrderStatus('${order.orderType}', ${order.id})" 
                            style="font-size: 12px; padding: 5px 10px;">
                        Mark as ${order.status.toLowerCase() === 'paid' ? 'Pending' : 'Paid'}
                    </button>
                </td>
            </tr>
        `;
        }).join('');
    }

    toggleOrderStatus(orderType, orderId) {
        if (orderType === 'Buy') {
            const orders = this.getBuyOrders();
            const orderIndex = orders.findIndex(order => order.id === orderId);
            
            if (orderIndex !== -1) {
                orders[orderIndex].status = orders[orderIndex].status === 'Paid' ? 'Pending' : 'Paid';
                this.saveBuyOrders(orders);
                this.loadAllOrders();
                this.showSuccessMessage(`Buy order status updated to ${orders[orderIndex].status}!`);
            }
        } else if (orderType === 'Sell') {
            const orders = this.getSellOrders();
            const orderIndex = orders.findIndex(order => order.id === orderId);
            
            if (orderIndex !== -1) {
                orders[orderIndex].status = orders[orderIndex].status === 'Paid' ? 'Pending' : 'Paid';
                this.saveSellOrders(orders);
                this.loadAllOrders();
                this.showSuccessMessage(`Sell order status updated to ${orders[orderIndex].status}!`);
            }
        }
    }

    formatDate(date) {
        return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showSuccessMessage(message) {
        const successDiv = document.getElementById('successMessage');
        const successText = document.getElementById('successText');
        
        successText.textContent = message;
        successDiv.style.display = 'block';
        
        setTimeout(() => {
            successDiv.style.display = 'none';
        }, 3000);
    }
}

let adminPanel;

document.addEventListener('DOMContentLoaded', function() {
    console.log('Romanian Leu Exchange - Admin Panel Loaded');
    adminPanel = new AdminPanel();
});