// Romanian Leu Exchange - Home Page JavaScript

class HomePageManager {
    constructor() {
        this.initializeData();
        this.updateRatesDisplay();
    }

    initializeData() {
        // Initialize settings if not exists
        if (!localStorage.getItem('ronSettings')) {
            const defaultSettings = {
                sellingRate: 0.35, // Rate for selling RON to customers (higher)
                buyingRate: 0.33   // Rate for buying RON from customers (lower)
            };
            localStorage.setItem('ronSettings', JSON.stringify(defaultSettings));
        }
    }

    getSettings() {
        return JSON.parse(localStorage.getItem('ronSettings'));
    }

    updateRatesDisplay() {
        const settings = this.getSettings();
        const buyingRateElement = document.getElementById('buyingRate');
        const sellingRateElement = document.getElementById('sellingRate');
        
        if (buyingRateElement) {
            buyingRateElement.textContent = `${settings.buyingRate} LKR per RON`;
        }
        
        if (sellingRateElement) {
            sellingRateElement.textContent = `${settings.sellingRate} LKR per RON`;
        }
    }
}

// Initialize the home page when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Romanian Leu Exchange - Home Page Loaded');
    new HomePageManager();
});