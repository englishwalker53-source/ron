import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Bot, 
  Send, 
  Sparkles, 
  TrendingUp, 
  Calendar, 
  Camera,
  DollarSign,
  Users,
  MessageSquare,
  Lightbulb
} from 'lucide-react';
import { FamilyAPI } from '@/lib/api';
import type { AIMessage } from '@/lib/mockData';

export default function AIAssistant() {
  const [messages, setMessages] = useState<AIMessage[]>(FamilyAPI.getAIMessages());
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const quickQuestions = [
    "Show me our expenses for this month",
    "What are our recent family photos?",
    "When is Emma's next birthday?",
    "How much did we spend on groceries?",
    "Show me our savings progress",
    "What family events are coming up?"
  ];

  const handleSendMessage = async () => {
    if (newMessage.trim()) {
      setIsTyping(true);
      
      // Add user message
      const userMessage: AIMessage = {
        id: Date.now().toString(),
        message: newMessage,
        sender: 'user',
        timestamp: new Date().toISOString(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      setNewMessage('');
      
      // Simulate AI thinking time
      setTimeout(() => {
        const aiMessage = FamilyAPI.sendAIMessage(newMessage);
        setMessages(prev => [...prev.slice(0, -1), userMessage, aiMessage]);
        setIsTyping(false);
      }, 1500);
    }
  };

  const handleQuickQuestion = (question: string) => {
    setNewMessage(question);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">AI Family Assistant</h1>
        <p className="text-muted-foreground">
          Your intelligent family companion for managing finances, memories, and daily tasks
        </p>
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* AI Capabilities Sidebar */}
        <div className="lg:col-span-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                AI Capabilities
              </CardTitle>
              <CardDescription>What I can help you with</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                <DollarSign className="h-4 w-4 text-green-600" />
                <span className="text-sm">Financial Analysis</span>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                <Camera className="h-4 w-4 text-blue-600" />
                <span className="text-sm">Memory Recall</span>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                <Calendar className="h-4 w-4 text-purple-600" />
                <span className="text-sm">Event Planning</span>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                <TrendingUp className="h-4 w-4 text-orange-600" />
                <span className="text-sm">Budget Insights</span>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                <Users className="h-4 w-4 text-indigo-600" />
                <span className="text-sm">Family Coordination</span>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted">
                <Lightbulb className="h-4 w-4 text-yellow-600" />
                <span className="text-sm">Smart Recommendations</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Questions</CardTitle>
              <CardDescription>Try asking me about these topics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {quickQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full text-left justify-start h-auto p-3 text-sm"
                    onClick={() => handleQuickQuestion(question)}
                  >
                    <MessageSquare className="h-4 w-4 mr-2 flex-shrink-0" />
                    <span className="truncate">{question}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <Card className="lg:col-span-8 flex flex-col h-[600px]">
          {/* Chat Header */}
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-3">
              <Avatar className="h-10 w-10">
                <div className="h-full w-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                  <Bot className="h-6 w-6 text-white" />
                </div>
              </Avatar>
              <div>
                <CardTitle className="text-lg">Family AI Assistant</CardTitle>
                <CardDescription className="flex items-center gap-2">
                  <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                  Online and ready to help
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          {/* Messages */}
          <CardContent className="flex-1 p-0 overflow-hidden">
            <ScrollArea className="h-full px-4">
              <div className="space-y-4 pb-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex items-start space-x-2 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                      <Avatar className="h-8 w-8 flex-shrink-0">
                        {message.sender === 'user' ? (
                          <>
                            <AvatarImage src="/api/placeholder/32/32" />
                            <AvatarFallback>JS</AvatarFallback>
                          </>
                        ) : (
                          <div className="h-full w-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                            <Bot className="h-4 w-4 text-white" />
                          </div>
                        )}
                      </Avatar>
                      <div className={`flex flex-col ${message.sender === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs text-muted-foreground">
                            {message.sender === 'user' ? 'You' : 'AI Assistant'}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {formatTime(message.timestamp)}
                          </span>
                        </div>
                        <div className={`p-3 rounded-lg ${
                          message.sender === 'user' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted'
                        }`}>
                          <p className="text-sm whitespace-pre-wrap">{message.message}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="flex items-start space-x-2 max-w-[80%]">
                      <Avatar className="h-8 w-8">
                        <div className="h-full w-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                          <Bot className="h-4 w-4 text-white" />
                        </div>
                      </Avatar>
                      <div className="bg-muted p-3 rounded-lg">
                        <div className="flex space-x-1">
                          <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce"></div>
                          <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="h-2 w-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>

          {/* Message Input */}
          <div className="p-4 border-t">
            <div className="flex items-center space-x-2">
              <div className="flex-1">
                <Input
                  placeholder="Ask me anything about your family's finances, memories, or plans..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={isTyping}
                />
              </div>
              <Button onClick={handleSendMessage} disabled={isTyping || !newMessage.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* AI Features */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Smart Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              Get intelligent insights about your spending patterns and financial health.
            </p>
            <Badge variant="secondary">Monthly Reports</Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              Event Reminders
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              Never miss important family events, birthdays, or appointments.
            </p>
            <Badge variant="secondary">Smart Notifications</Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-yellow-600" />
              Savings Goals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              Get personalized recommendations for achieving your family's financial goals.
            </p>
            <Badge variant="secondary">Goal Tracking</Badge>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}