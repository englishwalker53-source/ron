import { mockUsers, mockTransactions, mockPhotos, mockMemories, mockWhatsAppMessages, mockAIMessages } from './mockData';
import type { User, Transaction, Photo, Memory, WhatsAppMessage, AIMessage } from './mockData';

// Mock API functions using localStorage for persistence
export class FamilyAPI {
  private static getStorageKey(key: string): string {
    return `family_assistant_${key}`;
  }

  private static getFromStorage<T>(key: string, defaultValue: T[]): T[] {
    try {
      const stored = localStorage.getItem(this.getStorageKey(key));
      return stored ? JSON.parse(stored) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private static saveToStorage<T>(key: string, data: T[]): void {
    localStorage.setItem(this.getStorageKey(key), JSON.stringify(data));
  }

  // Users
  static getUsers(): User[] {
    return this.getFromStorage('users', mockUsers);
  }

  static getCurrentUser(): User {
    return this.getUsers()[0]; // Mock current user as admin
  }

  // Transactions
  static getTransactions(): Transaction[] {
    return this.getFromStorage('transactions', mockTransactions);
  }

  static addTransaction(transaction: Omit<Transaction, 'id'>): Transaction {
    const transactions = this.getTransactions();
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
    };
    transactions.push(newTransaction);
    this.saveToStorage('transactions', transactions);
    return newTransaction;
  }

  static deleteTransaction(id: string): void {
    const transactions = this.getTransactions().filter(t => t.id !== id);
    this.saveToStorage('transactions', transactions);
  }

  // Photos
  static getPhotos(): Photo[] {
    return this.getFromStorage('photos', mockPhotos);
  }

  static addPhoto(photo: Omit<Photo, 'id'>): Photo {
    const photos = this.getPhotos();
    const newPhoto: Photo = {
      ...photo,
      id: Date.now().toString(),
    };
    photos.push(newPhoto);
    this.saveToStorage('photos', photos);
    return newPhoto;
  }

  // Memories
  static getMemories(): Memory[] {
    return this.getFromStorage('memories', mockMemories);
  }

  static addMemory(memory: Omit<Memory, 'id'>): Memory {
    const memories = this.getMemories();
    const newMemory: Memory = {
      ...memory,
      id: Date.now().toString(),
    };
    memories.push(newMemory);
    this.saveToStorage('memories', memories);
    return newMemory;
  }

  // WhatsApp Messages
  static getWhatsAppMessages(): WhatsAppMessage[] {
    return this.getFromStorage('whatsapp_messages', mockWhatsAppMessages);
  }

  static sendWhatsAppMessage(message: Omit<WhatsAppMessage, 'id'>): WhatsAppMessage {
    const messages = this.getWhatsAppMessages();
    const newMessage: WhatsAppMessage = {
      ...message,
      id: Date.now().toString(),
    };
    messages.push(newMessage);
    this.saveToStorage('whatsapp_messages', messages);
    return newMessage;
  }

  // AI Messages
  static getAIMessages(): AIMessage[] {
    return this.getFromStorage('ai_messages', mockAIMessages);
  }

  static sendAIMessage(message: string): AIMessage {
    const messages = this.getAIMessages();
    const userMessage: AIMessage = {
      id: Date.now().toString(),
      message,
      sender: 'user',
      timestamp: new Date().toISOString(),
    };
    messages.push(userMessage);

    // Mock AI response
    const aiResponse = this.generateAIResponse(message);
    const aiMessage: AIMessage = {
      id: (Date.now() + 1).toString(),
      message: aiResponse,
      sender: 'ai',
      timestamp: new Date().toISOString(),
    };
    messages.push(aiMessage);

    this.saveToStorage('ai_messages', messages);
    return aiMessage;
  }

  private static generateAIResponse(userMessage: string): string {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('expense') || lowerMessage.includes('spending')) {
      const transactions = this.getTransactions();
      const expenses = transactions.filter(t => t.type === 'expense');
      const total = expenses.reduce((sum, t) => sum + t.amount, 0);
      return `Your total expenses are $${total.toFixed(2)}. The main categories are: ${expenses.slice(0, 3).map(t => `${t.category} ($${t.amount})`).join(', ')}.`;
    }
    
    if (lowerMessage.includes('income')) {
      const transactions = this.getTransactions();
      const income = transactions.filter(t => t.type === 'income');
      const total = income.reduce((sum, t) => sum + t.amount, 0);
      return `Your total income is $${total.toFixed(2)}. Great job managing your finances!`;
    }
    
    if (lowerMessage.includes('photo') || lowerMessage.includes('memory')) {
      const photos = this.getPhotos();
      return `You have ${photos.length} photos in your gallery. Recent uploads include: ${photos.slice(-2).map(p => p.caption).join(', ')}.`;
    }
    
    if (lowerMessage.includes('birthday') || lowerMessage.includes('event')) {
      return "I found Emma's birthday party memory from January 20th! It was a unicorn-themed celebration. Would you like me to show you the photos?";
    }
    
    return "I'm here to help with your family's finances, memories, and daily tasks. You can ask me about expenses, income, photos, or upcoming events!";
  }

  // Analytics
  static getExpensesByCategory(): { category: string; amount: number }[] {
    const transactions = this.getTransactions();
    const expenses = transactions.filter(t => t.type === 'expense');
    const categoryTotals: { [key: string]: number } = {};
    
    expenses.forEach(expense => {
      categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;
    });
    
    return Object.entries(categoryTotals).map(([category, amount]) => ({ category, amount }));
  }

  static getMonthlyTrends(): { month: string; income: number; expenses: number }[] {
    const transactions = this.getTransactions();
    const monthlyData: { [key: string]: { income: number; expenses: number } } = {};
    
    transactions.forEach(transaction => {
      const month = new Date(transaction.date).toLocaleDateString('en-US', { month: 'short' });
      if (!monthlyData[month]) {
        monthlyData[month] = { income: 0, expenses: 0 };
      }
      
      if (transaction.type === 'income') {
        monthlyData[month].income += transaction.amount;
      } else {
        monthlyData[month].expenses += transaction.amount;
      }
    });
    
    return Object.entries(monthlyData).map(([month, data]) => ({
      month,
      ...data
    }));
  }
}