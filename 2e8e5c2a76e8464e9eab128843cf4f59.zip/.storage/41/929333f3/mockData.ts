export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'member';
  avatar?: string;
  createdAt: Date;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  note: string;
  date: Date;
  userId: string;
}

export interface Photo {
  id: string;
  filePath: string;
  caption: string;
  tags: string[];
  uploadedBy: string;
  uploadedAt: Date;
}

export interface Memory {
  id: string;
  title: string;
  description: string;
  date: Date;
  photos: string[];
  createdBy: string;
  createdAt: Date;
}

export interface WhatsAppMessage {
  id: string;
  sender: string;
  message: string;
  timestamp: Date;
  type: 'text' | 'image' | 'command';
  processed?: boolean;
}

export interface AIMessage {
  id: string;
  message: string;
  response: string;
  timestamp: Date;
  userId: string;
}

// Mock data
export const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@family.com',
    role: 'admin',
    createdAt: new Date('2024-01-01'),
  },
  {
    id: '2',
    name: 'Sarah Smith',
    email: 'sarah@family.com',
    role: 'member',
    createdAt: new Date('2024-01-01'),
  },
  {
    id: '3',
    name: 'Mike Smith',
    email: 'mike@family.com',
    role: 'member',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '4',
    name: 'Emma Smith',
    email: 'emma@family.com',
    role: 'member',
    createdAt: new Date('2024-02-01'),
  },
];

export const mockTransactions: Transaction[] = [
  {
    id: '1',
    type: 'income',
    amount: 125000,
    category: 'Salary',
    note: 'Monthly salary - John',
    date: new Date('2024-10-01'),
    userId: '1',
  },
  {
    id: '2',
    type: 'income',
    amount: 85000,
    category: 'Salary',
    note: 'Monthly salary - Sarah',
    date: new Date('2024-10-01'),
    userId: '2',
  },
  {
    id: '3',
    type: 'expense',
    amount: 45000,
    category: 'Groceries',
    note: 'Weekly grocery shopping',
    date: new Date('2024-10-15'),
    userId: '2',
  },
  {
    id: '4',
    type: 'expense',
    amount: 25000,
    category: 'Utilities',
    note: 'Electricity bill',
    date: new Date('2024-10-10'),
    userId: '1',
  },
  {
    id: '5',
    type: 'expense',
    amount: 15000,
    category: 'Transportation',
    note: 'Fuel for car',
    date: new Date('2024-10-12'),
    userId: '1',
  },
  {
    id: '6',
    type: 'income',
    amount: 35000,
    category: 'Freelance',
    note: 'Web design project',
    date: new Date('2024-10-18'),
    userId: '2',
  },
  {
    id: '7',
    type: 'expense',
    amount: 8000,
    category: 'Entertainment',
    note: 'Movie night',
    date: new Date('2024-10-20'),
    userId: '3',
  },
  {
    id: '8',
    type: 'expense',
    amount: 12000,
    category: 'Healthcare',
    note: 'Doctor visit',
    date: new Date('2024-10-19'),
    userId: '4',
  },
];

export const mockPhotos: Photo[] = [
  {
    id: '1',
    filePath: '/api/placeholder/300/200',
    caption: 'Family vacation at the beach',
    tags: ['vacation', 'beach', 'family'],
    uploadedBy: '1',
    uploadedAt: new Date('2024-10-15'),
  },
  {
    id: '2',
    filePath: '/api/placeholder/300/200',
    caption: 'Birthday celebration',
    tags: ['birthday', 'celebration', 'cake'],
    uploadedBy: '2',
    uploadedAt: new Date('2024-10-10'),
  },
  {
    id: '3',
    filePath: '/api/placeholder/300/200',
    caption: 'Weekend hiking trip',
    tags: ['hiking', 'nature', 'weekend'],
    uploadedBy: '3',
    uploadedAt: new Date('2024-10-08'),
  },
  {
    id: '4',
    filePath: '/api/placeholder/300/200',
    caption: 'Home cooking session',
    tags: ['cooking', 'home', 'food'],
    uploadedBy: '4',
    uploadedAt: new Date('2024-10-05'),
  },
  {
    id: '5',
    filePath: '/api/placeholder/300/200',
    caption: 'Garden flowers blooming',
    tags: ['garden', 'flowers', 'spring'],
    uploadedBy: '1',
    uploadedAt: new Date('2024-10-03'),
  },
  {
    id: '6',
    filePath: '/api/placeholder/300/200',
    caption: 'Pet playing in the yard',
    tags: ['pet', 'yard', 'play'],
    uploadedBy: '2',
    uploadedAt: new Date('2024-10-01'),
  },
];

export const mockMemories: Memory[] = [
  {
    id: '1',
    title: 'Summer Beach Vacation',
    description: 'Amazing family trip to the coast with beautiful sunsets and great memories.',
    date: new Date('2024-10-15'),
    photos: ['1'],
    createdBy: '1',
    createdAt: new Date('2024-10-15'),
  },
  {
    id: '2',
    title: 'Emma\'s 16th Birthday',
    description: 'Celebrated Emma\'s sweet sixteen with family and friends.',
    date: new Date('2024-10-10'),
    photos: ['2'],
    createdBy: '2',
    createdAt: new Date('2024-10-10'),
  },
  {
    id: '3',
    title: 'Mountain Hiking Adventure',
    description: 'Weekend hiking trip to the mountains, great exercise and beautiful views.',
    date: new Date('2024-10-08'),
    photos: ['3'],
    createdBy: '3',
    createdAt: new Date('2024-10-08'),
  },
];

export const mockWhatsAppMessages: WhatsAppMessage[] = [
  {
    id: '1',
    sender: 'John Smith',
    message: 'Good morning family! Hope everyone has a great day.',
    timestamp: new Date('2024-10-21T08:00:00'),
    type: 'text',
  },
  {
    id: '2',
    sender: 'Sarah Smith',
    message: '/add-expense groceries 4500 Weekly shopping',
    timestamp: new Date('2024-10-21T10:30:00'),
    type: 'command',
    processed: true,
  },
  {
    id: '3',
    sender: 'Mike Smith',
    message: 'Can someone pick me up from school at 3 PM?',
    timestamp: new Date('2024-10-21T14:00:00'),
    type: 'text',
  },
  {
    id: '4',
    sender: 'Emma Smith',
    message: 'Thanks for the birthday surprise! 🎉',
    timestamp: new Date('2024-10-20T19:30:00'),
    type: 'text',
  },
  {
    id: '5',
    sender: 'John Smith',
    message: '/budget-summary',
    timestamp: new Date('2024-10-20T20:00:00'),
    type: 'command',
    processed: true,
  },
];

export const mockAIMessages: AIMessage[] = [
  {
    id: '1',
    message: 'What was our total spending last month?',
    response: 'Based on your transaction history, your family spent LKR 105,000 last month across categories: Groceries (LKR 45,000), Utilities (LKR 25,000), Transportation (LKR 15,000), Entertainment (LKR 8,000), and Healthcare (LKR 12,000). Your total income was LKR 245,000, leaving you with a positive balance of LKR 140,000.',
    timestamp: new Date('2024-10-21T09:15:00'),
    userId: '1',
  },
  {
    id: '2',
    message: 'Remind me about Emma\'s birthday photos',
    response: 'Emma\'s 16th birthday was celebrated on October 10th, 2024. You have photos from the celebration uploaded by Sarah, showing the birthday cake and family gathering. The memory is titled "Emma\'s 16th Birthday" with the description "Celebrated Emma\'s sweet sixteen with family and friends."',
    timestamp: new Date('2024-10-20T16:45:00'),
    userId: '2',
  },
  {
    id: '3',
    message: 'How can we save more money this month?',
    response: 'Based on your spending patterns, here are some suggestions: 1) Your grocery spending is LKR 45,000/month - consider meal planning to reduce by 15%. 2) Transportation costs LKR 15,000 - carpooling could save LKR 5,000. 3) Set a monthly entertainment budget of LKR 6,000 instead of LKR 8,000. These changes could save you approximately LKR 13,750 monthly.',
    timestamp: new Date('2024-10-19T11:20:00'),
    userId: '1',
  },
];