import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Camera, 
  Plus, 
  Search, 
  Calendar, 
  User,
  Heart,
  MessageCircle,
  Share2,
  Upload
} from 'lucide-react';
import { FamilyAPI } from '@/lib/api';
import type { Memory, Photo } from '@/lib/mockData';

export default function Memories() {
  const [memories, setMemories] = useState<Memory[]>(FamilyAPI.getMemories());
  const [photos, setPhotos] = useState<Photo[]>(FamilyAPI.getPhotos());
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingMemory, setIsAddingMemory] = useState(false);
  const [newMemory, setNewMemory] = useState({
    title: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  const filteredMemories = memories.filter(memory =>
    memory.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    memory.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddMemory = () => {
    if (newMemory.title && newMemory.description) {
      const memory = FamilyAPI.addMemory({
        ...newMemory,
        relatedPhotos: [],
        createdBy: 'John Smith'
      });
      setMemories([...memories, memory]);
      setNewMemory({ title: '', description: '', date: new Date().toISOString().split('T')[0] });
      setIsAddingMemory(false);
    }
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Simulate photo upload
      const photo = FamilyAPI.addPhoto({
        filePath: '/api/placeholder/400/300',
        caption: `New photo - ${file.name}`,
        uploadedBy: 'John Smith',
        date: new Date().toISOString().split('T')[0]
      });
      setPhotos([...photos, photo]);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Family Memories</h1>
          <p className="text-muted-foreground">
            Capture and cherish your family's precious moments
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isAddingMemory} onOpenChange={setIsAddingMemory}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Memory
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Memory</DialogTitle>
                <DialogDescription>
                  Add a special moment to your family's memory collection
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={newMemory.title}
                    onChange={(e) => setNewMemory({ ...newMemory, title: e.target.value })}
                    placeholder="e.g., Summer Vacation 2024"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newMemory.description}
                    onChange={(e) => setNewMemory({ ...newMemory, description: e.target.value })}
                    placeholder="Tell us about this special moment..."
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newMemory.date}
                    onChange={(e) => setNewMemory({ ...newMemory, date: e.target.value })}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsAddingMemory(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddMemory}>
                    Create Memory
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <div className="relative">
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Button variant="outline">
              <Upload className="mr-2 h-4 w-4" />
              Upload Photo
            </Button>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Search memories..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Photo Gallery */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Photo Gallery
          </CardTitle>
          <CardDescription>All your family photos in one place</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {photos.map((photo) => (
              <div key={photo.id} className="group relative">
                <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                  <img
                    src={photo.filePath}
                    alt={photo.caption}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                  <div className="text-center text-white p-2">
                    <p className="text-sm font-medium mb-1">{photo.caption}</p>
                    <p className="text-xs opacity-75">by {photo.uploadedBy}</p>
                  </div>
                </div>
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button size="sm" variant="secondary" className="h-8 w-8 p-0">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Memories */}
      <div className="space-y-6">
        <h2 className="text-2xl font-semibold">Memory Timeline</h2>
        <div className="grid gap-6">
          {filteredMemories.map((memory) => (
            <Card key={memory.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarImage src="/api/placeholder/40/40" />
                      <AvatarFallback>{memory.createdBy.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-semibold">{memory.title}</h3>
                      <div className="flex items-center text-sm text-muted-foreground gap-4">
                        <span className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {memory.createdBy}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(memory.date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Badge variant="secondary">Memory</Badge>
                </div>
                
                <p className="text-muted-foreground mb-4">{memory.description}</p>
                
                {memory.relatedPhotos.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                    {memory.relatedPhotos.map((photoId) => {
                      const photo = photos.find(p => p.id === photoId);
                      return photo ? (
                        <div key={photoId} className="aspect-square rounded-lg overflow-hidden bg-muted">
                          <img
                            src={photo.filePath}
                            alt={photo.caption}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ) : null;
                    })}
                  </div>
                )}
                
                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center space-x-4">
                    <Button variant="ghost" size="sm">
                      <Heart className="mr-2 h-4 w-4" />
                      Like
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Comment
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Share2 className="mr-2 h-4 w-4" />
                      Share
                    </Button>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {memory.relatedPhotos.length} photos
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {filteredMemories.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Camera className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No memories found</h3>
            <p className="text-muted-foreground text-center mb-4">
              {searchTerm ? 'Try adjusting your search terms' : 'Start creating beautiful memories with your family'}
            </p>
            <Button onClick={() => setIsAddingMemory(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Memory
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}