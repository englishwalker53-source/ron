export interface User {
  id: string;
  name: string;
  phone: string;
  role: 'admin' | 'parent' | 'child';
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  note: string;
  date: string;
}

export interface Photo {
  id: string;
  filePath: string;
  caption: string;
  uploadedBy: string;
  date: string;
}

export interface Memory {
  id: string;
  title: string;
  description: string;
  date: string;
  relatedPhotos: string[];
  createdBy: string;
}

export interface WhatsAppMessage {
  id: string;
  sender: string;
  message: string;
  timestamp: string;
  type: 'text' | 'image' | 'command';
}

export interface AIMessage {
  id: string;
  message: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

// Mock data
export const mockUsers: User[] = [
  { id: '1', name: 'John Smith', phone: '+1234567890', role: 'admin' },
  { id: '2', name: 'Sarah Smith', phone: '+1234567891', role: 'parent' },
  { id: '3', name: 'Emma Smith', phone: '+1234567892', role: 'child' },
  { id: '4', name: 'Jake Smith', phone: '+1234567893', role: 'child' }
];

export const mockTransactions: Transaction[] = [
  { id: '1', type: 'income', amount: 5000, category: 'Salary', note: 'Monthly salary', date: '2024-01-01' },
  { id: '2', type: 'expense', amount: 1200, category: 'Rent', note: 'Monthly rent payment', date: '2024-01-01' },
  { id: '3', type: 'expense', amount: 300, category: 'Groceries', note: 'Weekly shopping', date: '2024-01-02' },
  { id: '4', type: 'expense', amount: 150, category: 'Utilities', note: 'Electricity bill', date: '2024-01-03' },
  { id: '5', type: 'income', amount: 200, category: 'Freelance', note: 'Side project', date: '2024-01-05' },
  { id: '6', type: 'expense', amount: 80, category: 'Entertainment', note: 'Movie tickets', date: '2024-01-06' },
];

export const mockPhotos: Photo[] = [
  { id: '1', filePath: '/api/placeholder/400/300', caption: 'Family vacation at the beach', uploadedBy: 'Sarah Smith', date: '2024-01-15' },
  { id: '2', filePath: '/api/placeholder/400/300', caption: 'Emma\'s birthday party', uploadedBy: 'John Smith', date: '2024-01-20' },
  { id: '3', filePath: '/api/placeholder/400/300', caption: 'Jake\'s soccer game', uploadedBy: 'Sarah Smith', date: '2024-01-25' },
  { id: '4', filePath: '/api/placeholder/400/300', caption: 'Family dinner at grandma\'s', uploadedBy: 'Emma Smith', date: '2024-01-30' },
];

export const mockMemories: Memory[] = [
  {
    id: '1',
    title: 'Beach Vacation 2024',
    description: 'Amazing family trip to Miami Beach. Kids loved building sandcastles!',
    date: '2024-01-15',
    relatedPhotos: ['1'],
    createdBy: 'Sarah Smith'
  },
  {
    id: '2',
    title: 'Emma\'s 10th Birthday',
    description: 'Celebrated Emma\'s birthday with friends and family. Unicorn theme party!',
    date: '2024-01-20',
    relatedPhotos: ['2'],
    createdBy: 'John Smith'
  }
];

export const mockWhatsAppMessages: WhatsAppMessage[] = [
  { id: '1', sender: 'Sarah', message: 'Don\'t forget to pick up Emma from school at 3 PM', timestamp: '2024-01-01T14:30:00Z', type: 'text' },
  { id: '2', sender: 'John', message: 'Got it! Also, I added $50 expense for gas', timestamp: '2024-01-01T14:35:00Z', type: 'command' },
  { id: '3', sender: 'Emma', message: 'Can we have pizza for dinner?', timestamp: '2024-01-01T16:00:00Z', type: 'text' },
  { id: '4', sender: 'Jake', message: 'Look at my soccer trophy! 🏆', timestamp: '2024-01-01T17:00:00Z', type: 'image' },
];

export const mockAIMessages: AIMessage[] = [
  { id: '1', message: 'Hello! I\'m your family AI assistant. How can I help you today?', sender: 'ai', timestamp: '2024-01-01T10:00:00Z' },
  { id: '2', message: 'Show me our expenses for this month', sender: 'user', timestamp: '2024-01-01T10:01:00Z' },
  { id: '3', message: 'Your total expenses for January are $1,730. The largest category is Rent ($1,200), followed by Groceries ($300). Would you like a detailed breakdown?', sender: 'ai', timestamp: '2024-01-01T10:01:30Z' },
];