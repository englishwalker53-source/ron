import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  MessageSquare, 
  Send, 
  Phone, 
  Video, 
  MoreVertical,
  Image,
  Paperclip,
  Smile,
  Settings,
  Users,
  Bell
} from 'lucide-react';
import { FamilyAPI } from '@/lib/api';
import type { WhatsAppMessage } from '@/lib/mockData';

export default function WhatsApp() {
  const [messages, setMessages] = useState<WhatsAppMessage[]>(FamilyAPI.getWhatsAppMessages());
  const [newMessage, setNewMessage] = useState('');
  const [selectedContact, setSelectedContact] = useState('Family Group');

  const contacts = [
    { name: 'Family Group', lastMessage: 'Can we have pizza for dinner?', time: '5:00 PM', unread: 2 },
    { name: 'Sarah', lastMessage: 'Don\'t forget Emma\'s school pickup', time: '2:30 PM', unread: 0 },
    { name: 'Emma', lastMessage: 'Thanks for the lunch money!', time: '12:15 PM', unread: 1 },
    { name: 'Jake', lastMessage: 'Look at my soccer trophy! 🏆', time: '11:30 AM', unread: 0 },
  ];

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message = FamilyAPI.sendWhatsAppMessage({
        sender: 'John',
        message: newMessage,
        timestamp: new Date().toISOString(),
        type: 'text'
      });
      setMessages([...messages, message]);
      setNewMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">WhatsApp Integration</h1>
        <p className="text-muted-foreground">
          Stay connected with your family through WhatsApp
        </p>
      </div>

      <div className="grid lg:grid-cols-12 gap-6 h-[600px]">
        {/* Contacts Sidebar */}
        <Card className="lg:col-span-4">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Chats</CardTitle>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Settings className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Users className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[500px]">
              <div className="space-y-1">
                {contacts.map((contact, index) => (
                  <div key={contact.name}>
                    <div 
                      className={`flex items-center space-x-3 p-3 hover:bg-muted cursor-pointer transition-colors ${
                        selectedContact === contact.name ? 'bg-muted' : ''
                      }`}
                      onClick={() => setSelectedContact(contact.name)}
                    >
                      <Avatar>
                        <AvatarImage src="/api/placeholder/40/40" />
                        <AvatarFallback>{contact.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium truncate">{contact.name}</p>
                          <span className="text-xs text-muted-foreground">{contact.time}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-muted-foreground truncate">{contact.lastMessage}</p>
                          {contact.unread > 0 && (
                            <Badge variant="default" className="h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                              {contact.unread}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    {index < contacts.length - 1 && <Separator />}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="lg:col-span-8 flex flex-col">
          {/* Chat Header */}
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarImage src="/api/placeholder/40/40" />
                  <AvatarFallback>FG</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg">{selectedContact}</CardTitle>
                  <CardDescription>4 members • Online</CardDescription>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Phone className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Video className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>

          {/* Messages */}
          <CardContent className="flex-1 p-0">
            <ScrollArea className="h-[400px] px-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className="flex items-start space-x-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/api/placeholder/32/32" />
                      <AvatarFallback>{message.sender[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium">{message.sender}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatTime(message.timestamp)}
                        </span>
                        <Badge 
                          variant={message.type === 'command' ? 'secondary' : 'outline'} 
                          className="text-xs"
                        >
                          {message.type}
                        </Badge>
                      </div>
                      <div className={`inline-block p-3 rounded-lg max-w-md ${
                        message.sender === 'John' 
                          ? 'bg-primary text-primary-foreground ml-auto' 
                          : 'bg-muted'
                      }`}>
                        <p className="text-sm">{message.message}</p>
                        {message.type === 'image' && (
                          <div className="mt-2 w-full h-32 bg-muted-foreground/20 rounded flex items-center justify-center">
                            <Image className="h-8 w-8 text-muted-foreground" />
                          </div>
                        )}
                        {message.type === 'command' && (
                          <div className="mt-2 p-2 bg-background/20 rounded text-xs">
                            <p>✅ Command processed: Added expense</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>

          {/* Message Input */}
          <div className="p-4 border-t">
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Paperclip className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Image className="h-4 w-4" />
              </Button>
              <div className="flex-1">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                />
              </div>
              <Button variant="ghost" size="sm">
                <Smile className="h-4 w-4" />
              </Button>
              <Button onClick={handleSendMessage} size="sm">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* WhatsApp Commands Help */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            WhatsApp Commands
          </CardTitle>
          <CardDescription>
            Use these commands in your family chat to interact with the assistant
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <div className="p-3 border rounded-lg">
                <code className="text-sm font-mono bg-muted px-2 py-1 rounded">
                  /expense $50 groceries Weekly shopping
                </code>
                <p className="text-sm text-muted-foreground mt-1">Add a new expense</p>
              </div>
              <div className="p-3 border rounded-lg">
                <code className="text-sm font-mono bg-muted px-2 py-1 rounded">
                  /income $200 freelance Side project
                </code>
                <p className="text-sm text-muted-foreground mt-1">Record income</p>
              </div>
            </div>
            <div className="space-y-3">
              <div className="p-3 border rounded-lg">
                <code className="text-sm font-mono bg-muted px-2 py-1 rounded">
                  /balance
                </code>
                <p className="text-sm text-muted-foreground mt-1">Check current balance</p>
              </div>
              <div className="p-3 border rounded-lg">
                <code className="text-sm font-mono bg-muted px-2 py-1 rounded">
                  /remind Emma school pickup 3pm
                </code>
                <p className="text-sm text-muted-foreground mt-1">Set a family reminder</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Integration Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Integration Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="h-3 w-3 bg-green-500 rounded-full"></div>
              <div>
                <p className="font-medium">WhatsApp Cloud API</p>
                <p className="text-sm text-muted-foreground">Connected and active</p>
              </div>
            </div>
            <Badge variant="default">Active</Badge>
          </div>
          <div className="mt-4 p-4 bg-muted rounded-lg">
            <p className="text-sm">
              <strong>Note:</strong> This is a demo interface. In production, you would connect to WhatsApp Cloud API 
              or Twilio WhatsApp API to enable real messaging functionality.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}